'use strict';
window.addEventListener('DOMContentLoaded', () => {
  const ok = initFirebase();
  if (!ok) { UI.showPage('page-login'); return; }
  Auth.startAuthListener();
});
