'use strict';

const FIREBASE_CONFIG = {
  apiKey:            "AIzaSyCN1ZAC6yzNBs8zx24tY8_mjhLw6Bs70Ao",
  authDomain:        "reportlte-7d5a5.firebaseapp.com",
  projectId:         "reportlte-7d5a5",
  storageBucket:     "reportlte-7d5a5.firebasestorage.app",
  messagingSenderId: "841057197256",
  appId:             "1:841057197256:web:3e4ea0fd2bff56784199fd"
};

/* ── Status das ordens ───────────────────────── */
const STATUS_OPTS = [
  'Executada','Pendente de execução','Pendente de encerramento técnico',
  'Falta HH','Falta de material','Cancelada','Antecipada',
  'Em execução','Reprogramada','Bloqueio de acesso','Falta de liberação',
];
const STATUS_COLOR = {
  'Executada':                        '#00e676',
  'Pendente de execução':             '#ffab00',
  'Pendente de encerramento técnico': '#ff9800',
  'Falta HH':                         '#ff6b6b',
  'Falta de material':                '#f06292',
  'Cancelada':                        '#6888a8',
  'Antecipada':                       '#a78bfa',
  'Em execução':                      '#29b6f6',
  'Reprogramada':                     '#80cbc4',
  'Bloqueio de acesso':               '#ef9a9a',
  'Falta de liberação':               '#ce93d8',
  'default':                          '#6888a8',
};

/* ── Agenda ──────────────────────────────────── */
const IMPORTANCIA_OPTS  = ['Crítico','Importante','Moderado'];
const IMPORTANCIA_COLOR = {
  'Crítico':   '#ff1744',
  'Importante':'#ffab00',
  'Moderado':  '#00c6ff',
};

const SCALE_PATTERNS = {
  '1x1':   { work:1,  rest:1,  label:'1×1 — 1 dia trabalha, 1 folga'  },
  '3x3':   { work:3,  rest:3,  label:'3×3 — 3 dias trabalha, 3 folga' },
  '4x2':   { work:4,  rest:2,  label:'4×2 — 4 dias trabalha, 2 folga' },
  '5x2':   { work:5,  rest:2,  label:'5×2 — Seg a Sex (padrão)'       },
  '7x7':   { work:7,  rest:7,  label:'7×7 — 7 dias trabalha, 7 folga' },
  '14x14': { work:14, rest:14, label:'14×14 — 14 trabalha, 14 folga'  },
  '12x36h':{ work:1,  rest:2,  label:'12×36h — aprox. 1 dia/2 folga'  },
};

const TURMAS = ['A','B','C','D','ADM'];
const TURMA_COLOR = {
  'A':  { bg:'#1565C0', light:'#E3F2FD', text:'#1565C0' },
  'B':  { bg:'#2E7D32', light:'#E8F5E9', text:'#2E7D32' },
  'C':  { bg:'#F57F17', light:'#FFF8E1', text:'#E65100' },
  'D':  { bg:'#BF360C', light:'#FBE9E7', text:'#BF360C' },
  'ADM':{ bg:'#4527A0', light:'#EDE7F6', text:'#4527A0' },
};

const AUSENCIA_TIPOS = ['Folga','Férias','Licença Médica','Abono','Outro'];

/* ── Seed de usuários (para primeiro setup) ──── */
const SEED_USERS = [
  { nome:'Adriano Bíula',   email:'c0693929@vale.com', tel:'91980601360', perfil:'USER'          },
  { nome:'Daniel Oliveira', email:'c0699613@vale.com', tel:'61991812323', perfil:'USER'          },
  { nome:'Josué Gomes',     email:'c0698443@vale.com', tel:'91981908702', perfil:'ADMINISTRADOR' },
  { nome:'Jonatha Costa',   email:'c0699611@vale.com', tel:'86994764493', perfil:'USER'          },
  { nome:'Leno Dias',       email:'c0631672@vale.com', tel:'91980315905', perfil:'USER'          },
  { nome:'Lucas Cruz',      email:'c0655961@vale.com', tel:'94992119301', perfil:'USER'          },
  { nome:'Mateus Cardoso',  email:'c0707708@vale.com', tel:'94991745383', perfil:'USER'          },
  { nome:'Matheus Campos',  email:'c0719159@vale.com', tel:'',            perfil:'USER'          },
  { nome:'Robson Carmo',    email:'c0699118@vale.com', tel:'91981038107', perfil:'ADMINISTRADOR' },
  { nome:'Tales Augusto',   email:'c0719239@vale.com', tel:'63992851527', perfil:'USER'          },
  { nome:'Thiago Paranhos', email:'c0722621@vale.com', tel:'94991041848', perfil:'USER'          },
  { nome:'Waldecyr Souza',  email:'c0631638@vale.com', tel:'92050364949', perfil:'USER'          },
  { nome:'Wueder Trindade', email:'c0685815@vale.com', tel:'91984473488', perfil:'USER'          },
  { nome:'Wilian Santos',   email:'c0693925@vale.com', tel:'63992844141', perfil:'USER'          },
];
const DEFAULT_PASS = 'Vale@2026';

/* ── Globals Firebase ────────────────────────── */
let fbApp = null, fbDB = null, fbAuth = null;

function initFirebase() {
  if (FIREBASE_CONFIG.apiKey.includes('COLE_AQUI')) {
    document.getElementById('config-banner').style.display = 'block';
    return false;
  }
  try {
    fbApp  = firebase.initializeApp(FIREBASE_CONFIG);
    fbDB   = firebase.firestore();
    fbAuth = firebase.auth();
    fbDB.enablePersistence({ synchronizeTabs:true }).catch(() => {});
    return true;
  } catch(e) {
    console.error('Firebase init:', e);
    return false;
  }
}

function sanitize(s) {
  return String(s || '').trim()
    .replace(/&/g,'&amp;').replace(/</g,'&lt;')
    .replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&#x27;');
}
function fDate(d) {
  if (!d) return '—';
  const p = d.split('-');
  return p.length === 3 ? `${p[2]}/${p[1]}/${p[0]}` : d;
}
function serverTS() { return firebase.firestore.FieldValue.serverTimestamp(); }
function uid()      { return Date.now().toString(36) + Math.random().toString(36).slice(2); }