# 🐛 DEBUG LOG — ReportLTE v2.2
**Projeto:** LTE Sonda Report  
**Período:** 2026-05-09  
**Ambiente:** Produção (Netlify + Firebase)

---

## ✅ ISSUE #001 — Setup Inicial / Erros no `setupSystem`

**Sintoma:**
```
auth.js:62 Erros setup: Array(14)
(index):1 Uncaught (in promise) Error: A listener indicated an asynchronous 
response by returning true, but the message channel closed before a response 
was received
```

**Causa raiz:**
O erro `A listener indicated...` era ruído do Chrome Extension, não do Firebase.
Os 14 Auth users foram criados com sucesso. O verdadeiro problema era que os
documentos Firestore (`users` collection) não foram criados porque a coleção
ainda não existia no momento do primeiro setup.

**Solução aplicada:**
1. Verificado via Firebase Console que os 14 Auth users existiam
2. Extraídos os UIDs via JavaScript no Firebase Console
3. Temporariamente alterada a Firestore Rule `allow create: if true`
4. Criados os 14 documentos via Firestore REST API (PATCH)
5. Restaurada a rule original `allow create: if request.auth != null`

**Status:** ✅ Resolvido

---

## ✅ ISSUE #002 — Login retornando "Usuário ou senha inválidos"

**Sintoma:**
Após criação dos documentos Firestore, o login com `Vale@2026` retornava
erro genérico mesmo com credenciais corretas.

**Investigação:**
Teste direto via REST API confirmou que a senha `Vale@2026` funcionava:
```javascript
fetch('https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key=...',
  { method:'POST', body: JSON.stringify({email:'c0699118@vale.com', password:'Vale@2026'}) }
)
// Resultado: LOGIN OK - idToken: eyJhbGciOiJSUzI1NiIs...
```

**Causa raiz:**
A função `login()` executa `fbDB.collection('users').doc(uid).get()` ANTES
de o usuário estar autenticado. A Firestore Rule era:
```
allow get: if request.auth != null;  ← BLOQUEAVA leitura sem auth
```
Catch-22: precisava ler o e-mail para logar, mas precisava estar logado para ler.

**Solução aplicada:**
Alterada a rule de `get` na coleção `users`:
```
// Antes
allow get: if request.auth != null;

// Depois
allow get: if true;  ← seguro pois dados públicos não são sensíveis
```

**Justificativa de segurança:**
A coleção `users` já tinha `allow list: if true`. Expor `get` publicamente
é consistente e não adiciona risco, pois não há dados sensíveis (sem senhas,
sem tokens).

**Status:** ✅ Resolvido

---

## ✅ ISSUE #003 — Firebase projeto deletado durante setup

**Sintoma:**
Projeto `reportlte-c5109` foi excluído. Config.js apontava para projeto inexistente.

**Causa raiz:**
Usuário deletou o projeto Firebase original durante o processo de deploy.

**Solução aplicada:**
1. Criado novo projeto Firebase: `reportlte-7d5a5`
2. Atualizado `config.js` com novas credenciais
3. Reconfigurado: Auth (Email/Senha), Firestore, Rules, Domínios

**Status:** ✅ Resolvido

---

## ✅ ISSUE #004 — `accounts:update` rejeitado (INVALID_REQ_TYPE)

**Sintoma:**
Tentativa de redefinir senhas via REST API retornou:
```json
{ "error": { "message": "INVALID_REQ_TYPE : Unsupported request parameters." } }
```

**Causa raiz:**
O endpoint `accounts:update` exige `idToken` do usuário autenticado para
alterar sua própria senha. Não é possível redefinir senha de outro usuário
via API key sem autenticação admin (requer Firebase Admin SDK com service account).

**Solução alternativa:**
Verificado que as senhas originais `Vale@2026` estavam corretas (confirmado
pelo teste do ISSUE #002). O problema era nas Rules, não nas senhas.

**Status:** ✅ Resolvido (via ISSUE #002)

---

## ✅ ISSUE #005 — Netlify URL mudou após novo deploy

**Sintoma:**
Nova URL do site: `velvety-narwhal-5ac98a.netlify.app`  
Login retornava erro `auth/unauthorized-domain`.

**Causa raiz:**
Firebase Auth bloqueia logins de domínios não autorizados.

**Solução aplicada:**
Adicionado `velvety-narwhal-5ac98a.netlify.app` em:
Firebase Console → Authentication → Configurações → Domínios autorizados

**Domínios autorizados atuais:**
- `localhost`
- `reportlte-7d5a5.firebaseapp.com`
- `reportlte-7d5a5.web.app`
- `idyllic-chimera-b9df17.netlify.app` *(deploy anterior)*
- `velvety-narwhal-5ac98a.netlify.app` *(produção atual)*

**Status:** ✅ Resolvido

---

## ✅ ISSUE #006 — Redesign: migração standalone → Firebase

**Contexto:**
O projeto foi inicialmente construído com arquivos JS modulares separados
(auth.js, dashboard.js, editor.js, etc.) usando Firebase Compat SDK.
O usuário forneceu um HTML standalone funcional com localStorage como base
de design preferida.

**Solução aplicada:**
Criado novo `index.html` único que:
- Mantém 100% do design e UX do standalone
- Substitui localStorage por Firebase Firestore/Auth
- Remove dependência dos arquivos JS separados
- Mantém importação Excel (client-side) intacta
- Mantém exportação PDF/PNG/TXT intacta

**Arquivos JS separados** (auth.js, dashboard.js, etc.) permanecem no
servidor mas não são referenciados pelo novo index.html.

**Status:** ✅ Resolvido

---

## 📊 Timeline do Deploy

```
09:00 — Início do processo de deploy
09:15 — Firebase projeto reportlte-c5109 configurado (depois deletado)
09:30 — Novo Firebase projeto reportlte-7d5a5 criado
09:45 — Netlify deploy inicial (idyllic-chimera-b9df17)
10:00 — Domínio autorizado no Firebase
10:15 — Setup de usuários: Auth users criados, Firestore docs falharam
10:30 — Troubleshooting: extração de UIDs via JS no Firebase Console
10:45 — 14 documentos Firestore criados via REST API
11:00 — Bug login descoberto: Firestore Rules bloqueando get sem auth
11:15 — Rules corrigidas: allow get: if true para users collection
11:32 — Login funcionando com Vale@2026
11:45 — Redesign: novo index.html baseado em standalone HTML
12:00 — Novo deploy Netlify (velvety-narwhal-5ac98a)
12:15 — Domínio novo autorizado no Firebase
12:30 — GitHub repositório criado (mantoky/reportlte-app)
12:45 — Deploy completo e validado ✅
```

---

## 🔧 Configuração atual das Firestore Rules

```javascript
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /users/{userId} {
      allow list:   if true;
      allow get:    if true;                              // ← alterado em ISSUE #002
      allow create: if request.auth != null;
      allow update: if request.auth.uid == userId || isAdmin();
      allow delete: if isAdmin();
    }
    match /relatorios/{relId} {
      allow read:   if isAdmin() || resource.data.userId == request.auth.uid;
      allow create: if request.auth != null;
      allow update: if isAdmin() || resource.data.userId == request.auth.uid;
      allow delete: if isAdmin() || resource.data.userId == request.auth.uid;
    }
    function isAdmin() {
      return request.auth != null &&
        get(/databases/$(database)/documents/users/$(request.auth.uid)).data.perfil == 'ADMINISTRADOR';
    }
  }
}
```

---

## 📁 Estrutura de Arquivos (pós-redesign)

```
lte-app/
│   index.html          ← arquivo principal (único necessário)
│   netlify.toml        ← config Netlify
│   firestore.rules     ← backup das rules
│   .gitignore
│   DEBUG_LOG.md        ← este arquivo
│
├── css/                ← não referenciados pelo novo index.html
│   ├── style.css
│   └── agenda.css
│
└── js/                 ← não referenciados pelo novo index.html
    ├── config.js
    ├── app.js
    ├── ui.js
    ├── auth.js
    ├── dashboard.js
    ├── editor.js
    ├── admin.js
    ├── export.js
    ├── agenda.js
    └── upload.js
```

---

*Gerado em: 2026-05-09 | Setup por: Robson Carmo + Claude (Anthropic)*